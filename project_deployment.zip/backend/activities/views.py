from rest_framework import viewsets, status, serializers
from rest_framework.decorators import action
from rest_framework.response import Response
from django.db import transaction, IntegrityError
from django.utils import timezone
from django.core.cache import cache
from .models import Activity, Submission
from .serializers import ActivitySerializer, DailySubmissionSerializer, SubmissionSerializer
from .timeline import WAVE_LABELS
from users.permissions import OnboardingCompleted
from django.contrib.auth import get_user_model
import logging

logger = logging.getLogger(__name__)

User = get_user_model()

class DailyActivityViewSet(viewsets.ModelViewSet):
    """
    ViewSet for handling daily participant activities and submissions.
    """
    serializer_class = ActivitySerializer

    def get_queryset(self):
        user = self.request.user
        if not user.is_authenticated:
            return Activity.objects.none()
        from django.db.models import Q
        return Activity.objects.filter(Q(group=user.group) | Q(group__isnull=True))

    @action(detail=False, methods=['get'])
    def current(self, request):
        """
        Returns the current activity for the user based on their group and individual timeline.
        Uses Redis to cache the current day and submission status for maximum performance.
        """
        user = request.user
        activity_state = user.current_activity_state

        if not user.onboarding_completed_at:
            return Response({"detail": "Baseline not completed."}, status=status.HTTP_404_NOT_FOUND)

        if not activity_state:
            return Response({"detail": "No active activity period."}, status=status.HTTP_200_OK)

        current_day = activity_state.day_in_block
        activity_wave = activity_state.wave

        activity = None
        if user.group:
            activity = Activity.objects.filter(group=user.group, day_number=current_day).first()
        if not activity:
            activity = Activity.objects.filter(group__isnull=True, day_number=current_day).first()
        if not activity:
            return Response({"detail": f"No activity found for your group on Day {current_day}."}, status=status.HTTP_404_NOT_FOUND)
        
        serializer = self.get_serializer(activity)
        
        # Check if already submitted today using Redis caching
        today_date = timezone.localdate()
        cache_key = f"user_{user.user_id}_submitted_{today_date}"
        submitted_today = cache.get(cache_key)
        
        if submitted_today is None:
            # Fallback to DB and populate cache
            now_local = timezone.localtime(timezone.now())
            today_start = now_local.replace(hour=0, minute=0, second=0, microsecond=0)
            submitted_today = Submission.objects.filter(
                user=user,
                submission_date__gte=today_start
            ).exists()
            # Cache until end of day
            tomorrow = (now_local + timezone.timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
            timeout = int((tomorrow - now_local).total_seconds())
            if timeout > 0:
                cache.set(cache_key, submitted_today, timeout=timeout)
        
        data = serializer.data
        data['submitted_today'] = submitted_today
        data['current_day'] = current_day
        data['activity_wave'] = activity_wave
        data['activity_wave_label'] = WAVE_LABELS.get(activity_wave, activity_wave)
        
        if submitted_today:
            now_local = timezone.localtime(timezone.now())
            today_start = now_local.replace(hour=0, minute=0, second=0, microsecond=0)
            submission = Submission.objects.filter(user=user, submission_date__gte=today_start).first()
            if submission:
                data['submission_content'] = submission.content
                data['submission_id'] = submission.id
                data['entry_1'] = submission.entry_1
                data['entry_2'] = submission.entry_2
                data['entry_3'] = submission.entry_3
        
        response = Response(data)
        response['Cache-Control'] = 'no-cache, no-store, must-revalidate'
        response['Pragma'] = 'no-cache'
        response['Expires'] = '0'
        return response

    @action(detail=False, methods=['post'])
    def submit(self, request):
        """
        Submits the content for the user's daily activity.
        Uses database-level locking to prevent duplicate submissions during high load.
        """
        user = request.user
        
        # High-concurrency optimization: 
        # Use an atomic transaction and lock the user record during the check-and-create phase.
        with transaction.atomic():
            # Lock the user row to prevent race conditions from simultaneous requests
            User.objects.select_for_update().get(pk=user.user_id)
            
            # Re-check the submission state inside the lock
            # Submissions are locked once submitted. Block updates.
            now_local = timezone.localtime(timezone.now())
            today_start = now_local.replace(hour=0, minute=0, second=0, microsecond=0)
            existing_submission = Submission.objects.filter(user=user, submission_date__gte=today_start).first()
            
            if existing_submission:
                return Response(
                    {"detail": "This day's activity has already been submitted and is locked."}, 
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            activity_state = user.current_activity_state
            if not activity_state:
                return Response(
                    {"detail": "No active activity period."},
                    status=status.HTTP_400_BAD_REQUEST,
                )

            serializer = DailySubmissionSerializer(data=request.data, context={'request': request})
            if serializer.is_valid():
                try:
                    serializer.save(
                        user=user,
                        experiment_day=activity_state.day_in_block,
                        activity_wave=activity_state.wave,
                    )
                except IntegrityError:
                    return Response(
                        {"detail": "You have already made a submission for today or for this experiment day."}, 
                        status=status.HTTP_400_BAD_REQUEST
                    )
                
                # Update Redis cache to reflect submission
                today_date = timezone.localdate()
                cache_key = f"user_{user.user_id}_submitted_{today_date}"
                now_local = timezone.localtime(timezone.now())
                tomorrow = (now_local + timezone.timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
                timeout = int((tomorrow - now_local).total_seconds())
                if timeout > 0:
                    cache.set(cache_key, True, timeout=timeout)
                return Response(serializer.data, status=status.HTTP_201_CREATED)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class ActivityViewSet(viewsets.ReadOnlyModelViewSet):
    """
    Standard ViewSet for listing activities.
    """
    permission_classes = [OnboardingCompleted]
    queryset = Activity.objects.all()
    serializer_class = ActivitySerializer

class SubmissionViewSet(viewsets.ModelViewSet):
    """
    Standard ViewSet for handling task submissions.
    """
    permission_classes = [OnboardingCompleted]
    serializer_class = SubmissionSerializer

    def get_queryset(self):
        return Submission.objects.filter(user=self.request.user).order_by('-submission_date')

    def create(self, request, *args, **kwargs):
        try:
            return super().create(request, *args, **kwargs)
        except IntegrityError:
            return Response(
                {"detail": "You have already made a submission for today or for this experiment day."}, 
                status=status.HTTP_400_BAD_REQUEST
            )

    def perform_create(self, serializer):
        user = self.request.user
        activity_state = user.current_activity_state
        if not activity_state:
            raise serializers.ValidationError("No active activity period.")
        serializer.save(
            user=user,
            experiment_day=activity_state.day_in_block,
            activity_wave=activity_state.wave,
        )
